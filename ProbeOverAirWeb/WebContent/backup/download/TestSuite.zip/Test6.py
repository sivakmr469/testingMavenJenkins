'''
@author: Nishant Kumar
'''

import sys
import logging
from twisted.internet.defer import Deferred
from twisted.internet.protocol import DatagramProtocol
from twisted.internet import reactor
from twisted.python import log
import txthings.coap as coap
import txthings.resource as resource
import getopt
import datetime
import logging
import xml.etree.cElementTree as ET
import pprint
import serial
import xbee
import time


def getxbee():
    #print("Executing Script: Fetch Sensor Value")
    SERIAL_PORT = '/dev/ttyUSB0'
    BAUD_RATE = 9600
    # Instantiate an instance for the serial port
    ser_port = serial.Serial(SERIAL_PORT, BAUD_RATE)

    # Instantiate an instance of the ZigBee class
    # and pass it an instance of the Serial class
    xbee1 = xbee.zigbee.ZigBee(ser_port)
    trans_f='g';

    client = None
    ser_port.flushInput() #flush input buffer, discarding all its contents
    ser_port.flushOutput()#flush output buffer, aborting current output
        #and discard all that is in buffer

    # Read a data frame from the XBee
    data_samples = xbee1.wait_read_frame()
    #pprint.pprint(data_samples)
    trans=data_samples['samples']
    trans_f=trans[0]
    trans_p=trans_f['dio-0']
    z=str(trans_p)
    #print(trans_p)
    file_object=open("xbee_output.txt","w")
    file_object.write(z)
    while KeyboardInterrupt==1:
        file_object.close
        reactor.stop()
        break
    return (trans_p)
    
class Agent():
    """
    Example class which performs single PUT request to iot.eclipse.org
    port 5683 (official IANA assigned CoAP port), URI "/large-update".
    Request is sent 1 second after initialization.

    Payload is bigger than 64 bytes, and with default settings it
    should be sent as several blocks.
    """
    

    def __init__(self, protocol):
        self.protocol = protocol
        reactor.callLater(2, self.postResource)
        

    def postResource(self):
        
        #global client
        #data=str(getxbee())
        data=str(False)
        #print("__________________________________"+data)
        time.sleep(1)
        obj=ET.Element("obj")
        ET.SubElement(obj,"Str", name="appId", val="LDR").text
        ET.SubElement(obj,"Int", name="category", val="light").text
        ET.SubElement(obj,"Int", name="data", val=data).text
        ET.SubElement(obj,"Int", name="unit", val="luminiscence").text
        tree=ET.ElementTree(obj)
        tree.write("payload.xml",encoding="UTF-8",xml_declaration=None,default_namespace=None,method="xml")
        time.sleep(1)
        print("Sensor Value: "+data)
        ipadd= open('/home/pi/Downloads/projects/ALL_sensor/IPAdd.txt').read()
        payload = open('/home/pi/Downloads/projects/ALL_sensor/LDR/payload.xml').read()
        request = coap.Message(code=coap.POST, payload=payload)
        request.opt.uri_path = ('om2m/gscl/applications/LDR/containers/DATA/contentInstances',)
        request.opt.uri_query = ('authorization=admin:admin',)
        request.opt.content_format = coap.media_types_rev['application/xml']
        request.remote = (ipadd, coap.COAP_PORT)
        d = protocol.request(request)
        d.addCallback(self.printResponse)
        
        
    def printResponse(self, response):
        print ('Response Code is: ' + coap.responses[response.code])
         # Check resuting state of fake device
        expected_result = "2.01 Created"
        if str(coap.responses[response.code])==expected_result:
            print("Test Script 6(Fetching Content Instance):Pass")
	    logging.basicConfig(level=logging.DEBUG, filename="logfile", filemode="a+",format="%(asctime)-15s %(levelname)-8s %(message)s")
	    logging.info("Test case 6 passed!!!")
            reactor.stop()
        else:
            print("Test Script 6(Fetching Content Instance):Fail")
	    logging.basicConfig(level=logging.DEBUG, filename="logfile", filemode="a+",format="%(asctime)-15s %(levelname)-8s %(message)s")
	    logging.info("Test case 6 failed!!!")
            reactor.stop()
#log.startLogging(sys.stdout)

endpoint = resource.Endpoint(None)
protocol = coap.Coap(endpoint)
client = Agent(protocol)

reactor.listenUDP(61616, protocol)
reactor.run()

