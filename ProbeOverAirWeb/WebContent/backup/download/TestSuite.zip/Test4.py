'''
@author: Nishant Kumar
@author: Tarun Navadia
'''

import sys
import logging
from twisted.internet.defer import Deferred
from twisted.internet.protocol import DatagramProtocol
from twisted.internet import reactor
from twisted.python import log

import txthings.coap as coap
import txthings.resource as resource


class Agent():
    """
    Example class which performs single PUT request to iot.eclipse.org
    port 5683 (official IANA assigned CoAP port), URI "/large-update".
    Request is sent 1 second after initialization.

    Payload is bigger than 64 bytes, and with default settings it
    should be sent as several blocks.
    """

    def __init__(self, protocol):
        self.protocol = protocol
        reactor.callLater(2, self.postResource)

    def postResource(self):
        ipadd= open('/home/pi/Downloads/projects/ALL_sensor/IPAdd.txt').read()
        payload = open('/home/pi/Downloads/projects/ALL_sensor/LDR/oM2M_Resource_Creation/DataContainer.xml').read()
        request = coap.Message(code=coap.POST, payload=payload)
        request.opt.uri_path = ('om2m/gscl/applications/LDR/containers',)
        request.opt.uri_query = ('authorization=admin:admin',)
        request.opt.content_format = coap.media_types_rev['application/xml']
        request.remote = (ipadd, coap.COAP_PORT)
        d = protocol.request(request)
        d.addCallback(self.printResponse)
        
    def printResponse(self, response):
        print ('Response Code is: ' + coap.responses[response.code])
         # Test Case
        expected_result = "2.01 Created"
        if str(coap.responses[response.code])==expected_result:
            print("Test Script 4(DATA Container Creation): Pass")
	    logging.basicConfig(level=logging.DEBUG, filename="logfile", filemode="a+",format="%(asctime)-15s %(levelname)-8s %(message)s")
	    logging.info("Test case 4 passed!!!")
            print(".........................")
        else:
            print("Test Script 4(DATA Container Creation): Fail")
	    logging.basicConfig(level=logging.DEBUG, filename="logfile", filemode="a+",format="%(asctime)-15s %(levelname)-8s %(message)s")
	    logging.info("Test case 4 failed!!!")
            print(".........................")

        var=0
        if var==0:
            reactor.stop()

#log.startLogging(sys.stdout)

endpoint = resource.Endpoint(None)
protocol = coap.Coap(endpoint)
client = Agent(protocol)

reactor.listenUDP(61616, protocol)
reactor.run()

